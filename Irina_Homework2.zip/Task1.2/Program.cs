﻿namespace Task1._2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Write your name, surname, age and profession: ");
            string information = Console.ReadLine();
        }
    }
}
