﻿namespace Task2._2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please press any key to clear the console...");
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("The console has been cleared.");
        }
    }
}
