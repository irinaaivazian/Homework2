﻿namespace Task2._4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int frequency = 500;
            int duration = 100;
            Console.Beep(frequency, duration);
        }
    }
}
